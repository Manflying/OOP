/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package karyawan;

/**
 *
 * @author Mahasiswa
 */
public class Karyawan {
private String nip;
private String nama;
private String jabatan;
public String getNip() {
return nip;
}
public void setNip(String nip) {
this.nip = nip;
}
public String getNama() {
return nama;
}
public void setNama(String nama) {
this.nama = nama;
}
public String getJabatan() {
return jabatan;
}
public void setJabatan(String jabatan) {
this.jabatan = jabatan;
}
public static void main(String[] args) {
Karyawan karyawan1 = new Karyawan();
karyawan1.setNip("123456789");
karyawan1.setNama("John Doe");
karyawan1.setJabatan("Manager");

Karyawan karyawan2 = new Karyawan();
karyawan2.setNip("13123154");
karyawan2.setNama("April Costan");
karyawan2.setJabatan("Directur");

System.out.println("Informasi Karyawan:");
System.out.println("NIP: " + karyawan1.getNip());
System.out.println("Nama: " + karyawan1.getNama());
System.out.println("Jabatan: " + karyawan1.getJabatan());

System.out.println("Informasi Karyawan:");
System.out.println("NIP: " + karyawan2.getNip());
System.out.println("Nama: " + karyawan2.getNama());
System.out.println("Jabatan: " + karyawan2.getJabatan());
}
}
