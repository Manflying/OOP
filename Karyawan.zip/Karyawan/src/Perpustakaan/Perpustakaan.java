/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Perpustakaan;

/**
 *
 * @author Mahasiswa
 */
public class Perpustakaan {
private String nama;
private String lokasi;
private int jumlahBuku;
public Perpustakaan(String nama, String lokasi, int jumlahBuku) {
this.nama = nama;
this.lokasi = lokasi;
this.jumlahBuku = jumlahBuku;
}
public String getNama() {
return nama;
}
public void setNama(String nama) {
this.nama = nama;
}
public String getLokasi() {
return lokasi;
}
public void setLokasi(String lokasi) {
this.lokasi = lokasi;
}
public int getJumlahBuku() {
return jumlahBuku;
}
public void setJumlahBuku(int jumlahBuku) {
this.jumlahBuku = jumlahBuku;
}
public static void main(String[] args) {
Perpustakaan perpustakaan = new Perpustakaan("Perpustakaan Umum",
"Jakarta", 10000);
System.out.println("Informasi Perpustakaan:");
System.out.println("Nama: " + perpustakaan.getNama());
System.out.println("Lokasi: " + perpustakaan.getLokasi());
System.out.println("Jumlah Buku: " + perpustakaan.getJumlahBuku());

Perpustakaan perpustakaan1 = new Perpustakaan("Perpustakaan Umum",
"Bandung", 1000);
System.out.println("Informasi Perpustakaan:");
System.out.println("Nama: " + perpustakaan1.getNama());
System.out.println("Lokasi: " + perpustakaan1.getLokasi());
System.out.println("Jumlah Buku: " + perpustakaan1.getJumlahBuku());
}
}
