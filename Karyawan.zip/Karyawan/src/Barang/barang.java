/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Barang;

/**
 *
 * @author Mahasiswa
 */
public class barang {
private String kode;
private String namabarang;
private double harga;

public barang(String kode, String namabarang, double harga) {
this.kode = kode;
this.namabarang = namabarang;
this.harga = harga;
}
public String getKode() {
return kode;
}
public void setKode(String kode) {
this.kode = kode;
}
public String getNamabarang() {
return namabarang;
}
public void setNamabarang(String namabarang) {
this.namabarang = namabarang;
}
public double getHarga() {
return harga;
}
public void setHarga(double harga) {
this.harga = harga;
}
public static void main(String[] args) {

    barang barang1 = new barang("001", "Buku Tulis", 5000);

System.out.println("Kode Barang: " + barang1.getKode());
System.out.println("Nama Barang: " + barang1.getNamabarang());
System.out.println("Harga Barang: " + barang1.getHarga());
}
}
