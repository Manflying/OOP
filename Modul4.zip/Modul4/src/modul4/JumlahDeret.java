/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul4;

/**
 *
 * @author Mahasiswa
 */
public class JumlahDeret {
    public static void main(String[] args){
        int  n = 5;
        int jumlah = 0;
        int i = 1;
        while (i <= n){
        jumlah += i;
        i++;
    }
        System.out.println("Jumlah deret: " + jumlah);
    }
}
