/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul4;

/**
 *
 * @author Mahasiswa
 */
public class CetakBilanganGenap {
    public static void main(String[] args) {
        int n = 10;
        for (int i = 1; i  <= n; i++) {
        if (i % 2 == 0) {
            System.out.println(i);
        }
     }
    }
}
